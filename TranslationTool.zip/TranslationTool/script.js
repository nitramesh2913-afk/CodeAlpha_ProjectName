/* ═══════════════════════════════════════════════
   Globe animation
═══════════════════════════════════════════════ */

(function initGlobe() {
  const canvas = document.getElementById('globe');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  const W = 40, H = 40, R = 17, cx = W / 2, cy = H / 2;

  const dots = [];
  for (let lat = -80; lat <= 80; lat += 22) {
    const cosLat = Math.cos((lat * Math.PI) / 180);
    const count = Math.max(4, Math.round(cosLat * 14));
    for (let i = 0; i < count; i++) {
      dots.push({
        lat: (lat * Math.PI) / 180,
        lng: ((i / count) * 360 - 180) * (Math.PI / 180),
      });
    }
  }

  let rot = 0;

  function draw() {
    ctx.clearRect(0, 0, W, H);

    // sphere background
    ctx.beginPath();
    ctx.arc(cx, cy, R, 0, Math.PI * 2);
    const isDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
    ctx.fillStyle = isDark ? '#1e1d17' : '#f1f0ec';
    ctx.fill();
    ctx.strokeStyle = isDark ? 'rgba(255,255,255,0.1)' : 'rgba(0,0,0,0.1)';
    ctx.lineWidth = 0.5;
    ctx.stroke();

    // dots
    for (const d of dots) {
      const lng = d.lng + rot;
      const x3 = Math.cos(d.lat) * Math.sin(lng);
      const y3 = Math.sin(d.lat);
      const z3 = Math.cos(d.lat) * Math.cos(lng);
      if (z3 < 0) continue;
      const sx = cx + x3 * R;
      const sy = cy - y3 * R;
      const alpha = 0.25 + 0.65 * z3;
      ctx.beginPath();
      ctx.arc(sx, sy, 0.9, 0, Math.PI * 2);
      ctx.fillStyle = isDark
        ? `rgba(133,183,235,${alpha})`
        : `rgba(24,95,165,${alpha})`;
      ctx.fill();
    }

    rot += 0.006;
    requestAnimationFrame(draw);
  }

  draw();
})();

/* ═══════════════════════════════════════════════
   Language data
═══════════════════════════════════════════════ */

const LANGUAGES = [
  { code: 'ta', label: 'Tamil',      flag: '🇮🇳' },
  { code: 'hi', label: 'Hindi',      flag: '🇮🇳' },
  { code: 'fr', label: 'French',     flag: '🇫🇷' },
  { code: 'de', label: 'German',     flag: '🇩🇪' },
  { code: 'es', label: 'Spanish',    flag: '🇪🇸' },
  { code: 'ja', label: 'Japanese',   flag: '🇯🇵' },
  { code: 'zh', label: 'Chinese',    flag: '🇨🇳' },
  { code: 'ar', label: 'Arabic',     flag: '🇸🇦' },
  { code: 'ko', label: 'Korean',     flag: '🇰🇷' },
  { code: 'ru', label: 'Russian',    flag: '🇷🇺' },
  { code: 'pt', label: 'Portuguese', flag: '🇧🇷' },
  { code: 'it', label: 'Italian',    flag: '🇮🇹' },
];

/* ═══════════════════════════════════════════════
   State
═══════════════════════════════════════════════ */

const selected = new Set(['ta', 'fr', 'es']);

/* ═══════════════════════════════════════════════
   Language pills
═══════════════════════════════════════════════ */

const langGrid = document.getElementById('langGrid');

LANGUAGES.forEach((lang) => {
  const pill = document.createElement('button');
  pill.className = 'lang-pill' + (selected.has(lang.code) ? ' active' : '');
  pill.dataset.code = lang.code;
  pill.setAttribute('role', 'checkbox');
  pill.setAttribute('aria-checked', selected.has(lang.code) ? 'true' : 'false');
  pill.type = 'button';
  pill.innerHTML = `<span class="flag" aria-hidden="true">${lang.flag}</span>${lang.label}`;

  pill.addEventListener('click', () => {
    const active = selected.has(lang.code);
    if (active) {
      selected.delete(lang.code);
      pill.classList.remove('active');
      pill.setAttribute('aria-checked', 'false');
      // remove its card if present
      const card = document.getElementById('card-' + lang.code);
      if (card) card.remove();
    } else {
      selected.add(lang.code);
      pill.classList.add('active');
      pill.setAttribute('aria-checked', 'true');
    }
  });

  langGrid.appendChild(pill);
});

/* ═══════════════════════════════════════════════
   Char counter + clear
═══════════════════════════════════════════════ */

const srcText = document.getElementById('srcText');
const charCount = document.getElementById('charCount');

srcText.addEventListener('input', () => {
  charCount.textContent = srcText.value.length + ' / 3000';
});

document.getElementById('clearBtn').addEventListener('click', () => {
  srcText.value = '';
  charCount.textContent = '0 / 3000';
  document.getElementById('resultsGrid').innerHTML = '';
  srcText.focus();
});

/* ═══════════════════════════════════════════════
   Result card factory
═══════════════════════════════════════════════ */

function createCard(lang) {
  const card = document.createElement('div');
  card.className = 'result-card';
  card.id = 'card-' + lang.code;

  card.innerHTML = `
    <div class="card-head">
      <span class="card-lang">
        <span class="flag" aria-hidden="true">${lang.flag}</span>
        ${lang.label}
      </span>
      <span class="card-status loading" id="status-${lang.code}" aria-live="polite"></span>
    </div>
    <div class="card-body placeholder translating" id="body-${lang.code}" aria-label="${lang.label} translation">
      Translating…
    </div>
    <div class="card-foot">
      <button class="icon-btn" id="copy-${lang.code}" title="Copy" aria-label="Copy ${lang.label} translation" disabled>
        <svg width="14" height="14" viewBox="0 0 14 14" fill="none" aria-hidden="true">
          <rect x="4.5" y="4.5" width="8" height="8" rx="1.5" stroke="currentColor" stroke-width="1.2"/>
          <path d="M2.5 9.5h-.5A1.5 1.5 0 0 1 .5 8V2A1.5 1.5 0 0 1 2 .5h6A1.5 1.5 0 0 1 9.5 2v.5" stroke="currentColor" stroke-width="1.2"/>
        </svg>
      </button>
      <button class="icon-btn" id="speak-${lang.code}" title="Listen" aria-label="Listen to ${lang.label}" disabled>
        <svg width="14" height="14" viewBox="0 0 14 14" fill="none" aria-hidden="true">
          <path d="M2 5H4.5L7.5 2.5v9L4.5 9H2V5z" stroke="currentColor" stroke-width="1.2" stroke-linejoin="round"/>
          <path d="M10 4.5a3 3 0 0 1 0 5" stroke="currentColor" stroke-width="1.2" stroke-linecap="round"/>
        </svg>
      </button>
    </div>`;

  return card;
}

function attachCardActions(lang) {
  const copyBtn = document.getElementById('copy-' + lang.code);
  const speakBtn = document.getElementById('speak-' + lang.code);

  copyBtn.addEventListener('click', () => {
    const body = document.getElementById('body-' + lang.code);
    const text = body.dataset.result || '';
    if (!text) return;
    navigator.clipboard.writeText(text).then(() => {
      copyBtn.classList.add('copied');
      copyBtn.innerHTML = `
        <svg width="14" height="14" viewBox="0 0 14 14" fill="none" aria-hidden="true">
          <path d="M2 7l3.5 3.5L12 3" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
        </svg>`;
      setTimeout(() => {
        copyBtn.classList.remove('copied');
        copyBtn.innerHTML = `
          <svg width="14" height="14" viewBox="0 0 14 14" fill="none" aria-hidden="true">
            <rect x="4.5" y="4.5" width="8" height="8" rx="1.5" stroke="currentColor" stroke-width="1.2"/>
            <path d="M2.5 9.5h-.5A1.5 1.5 0 0 1 .5 8V2A1.5 1.5 0 0 1 2 .5h6A1.5 1.5 0 0 1 9.5 2v.5" stroke="currentColor" stroke-width="1.2"/>
          </svg>`;
      }, 1800);
    });
  });

  speakBtn.addEventListener('click', () => {
    const body = document.getElementById('body-' + lang.code);
    const text = body.dataset.result || '';
    if (!text) return;
    window.speechSynthesis.cancel();
    const utt = new SpeechSynthesisUtterance(text);
    window.speechSynthesis.speak(utt);
  });
}

/* ═══════════════════════════════════════════════
   Translation API
═══════════════════════════════════════════════ */

const ENDPOINTS = [
  'https://libretranslate.de/translate',
  'https://translate.terraprint.co/translate',
];

async function translateOne(text, targetCode) {
  for (const endpoint of ENDPOINTS) {
    try {
      const res = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          q: text,
          source: 'en',
          target: targetCode,
          format: 'text',
        }),
        signal: AbortSignal.timeout(9000),
      });
      if (!res.ok) continue;
      const data = await res.json();
      if (data.translatedText) return data.translatedText;
    } catch (_) {
      // try next endpoint
    }
  }
  return null;
}

/* ═══════════════════════════════════════════════
   Translate button
═══════════════════════════════════════════════ */

const translateBtn = document.getElementById('translateBtn');
const btnLabel = document.getElementById('btnLabel');
const btnIcon = document.getElementById('btnIcon');
const resultsGrid = document.getElementById('resultsGrid');

translateBtn.addEventListener('click', async () => {
  const text = srcText.value.trim();
  if (!text) {
    srcText.focus();
    return;
  }
  if (selected.size === 0) return;

  // Lock UI
  translateBtn.disabled = true;
  btnLabel.textContent = 'Translating…';
  btnIcon.classList.add('spinning');

  // Build / reset cards
  resultsGrid.innerHTML = '';
  const targets = [...selected].map((code) => LANGUAGES.find((l) => l.code === code));

  targets.forEach((lang) => {
    const card = createCard(lang);
    resultsGrid.appendChild(card);
    attachCardActions(lang);
  });

  // Fire all requests in parallel
  const tasks = targets.map(async (lang) => {
    const result = await translateOne(text, lang.code);
    const body = document.getElementById('body-' + lang.code);
    const status = document.getElementById('status-' + lang.code);
    const copyBtn = document.getElementById('copy-' + lang.code);
    const speakBtn = document.getElementById('speak-' + lang.code);

    body.classList.remove('translating', 'placeholder');

    if (result) {
      body.textContent = result;
      body.dataset.result = result;
      status.textContent = 'done';
      status.className = 'card-status ok';
      copyBtn.disabled = false;
      speakBtn.disabled = false;
    } else {
      body.textContent = 'Translation unavailable. Check your connection or try again.';
      body.classList.add('placeholder');
      status.textContent = 'error';
      status.className = 'card-status err';
    }
  });

  await Promise.allSettled(tasks);

  // Unlock UI
  translateBtn.disabled = false;
  btnLabel.textContent = 'Translate';
  btnIcon.classList.remove('spinning');
});

/* ── Keyboard shortcut: Ctrl/Cmd + Enter ── */
srcText.addEventListener('keydown', (e) => {
  if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
    translateBtn.click();
  }
});
